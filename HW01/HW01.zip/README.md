## Getting Started

    If you want this to work you need to instal 'Extension Pack for Java' in extensions in VS Code and 'Drawing.jar' app.

    After you made new Java project make sure 'Drawing.jar' is in the same folder so you don't have a problem with is later. 
    
    Connecting 'Drawing.jar' and your project you do in: 'Java projects'(on the bottom od side bar) -> Referenced Libraries -> + ("add") -> (find where you put it)Drawing.jar 

## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

Meanwhile, the compiled output files will be generated in the `bin` folder by default.

> If you want to customize the folder structure, open `.vscode/settings.json` and update the related settings there.

## Dependency Management

The `JAVA PROJECTS` view allows you to manage your dependencies. More details can be found [here](https://github.com/microsoft/vscode-java-dependency#manage-dependencies).

I DO NOT OWN THE PROJECT ONLY THE CODE/SOME OF THE CODE!!!!!! DO NOT COPY FROM ME!!!!