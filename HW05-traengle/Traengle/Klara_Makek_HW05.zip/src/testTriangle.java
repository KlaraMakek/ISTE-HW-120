public class testTriangle {
    public static void main(String[] args) {
        Triangle test = new Triangle(0,0,4,0,3,3);
        System.out.println("Triangle with coordinates: A(0.0,0.0), B(4.0,0.0), C(3.0,3.0)");
        System.out.println(test.toString());
    }
    
}
